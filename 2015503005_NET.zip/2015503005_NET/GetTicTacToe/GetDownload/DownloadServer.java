import java.net.*;
import java.io.*;
import java.util.*;

/*1. Write a server application which listens a given TCP port and 
it provides a simple http Service to pass back a requested file 
in the server's directory or subdirectory. 
The request from a browser should be in the form: 
"GET /path/filename.xyz". 
If no file name or only “ / ” in the request, the server passes the default index.html 
file from server’s directory. 
If requested file is not found, it passes “404 Object not found”. 
If requested file is found but it don’t have a permission to read, the servers passes “403 Forbidden”. 
If any other error is occurred, the server passes “400 Bad request”. 
The program argument is the port number. 
The default value of port number is 1234.*/

public class DownloadServer {
 	  public static void main(String[] args) {
 	  	try {
	 	  	ServerSocket ss = new ServerSocket(1234);
	 	  	Socket s = ss.accept();
	 	  	DataInputStream in = new DataInputStream(s.getInputStream());
	 	  	DataOutputStream out = new DataOutputStream(s.getOutputStream());
	 	  	Scanner scan = new Scanner(System.in) ;
	 	  	Thread receive = new Thread() {
	 	  		public void run() {
	 	  			try {
	 	  				while(true) {
	 	  					String receivedMessage = in.readUTF();
	 	  					String URL = receivedMessage.substring(4, receivedMessage.length());
	 	  					System.out.println("SERVER SENDING " + URL);
	 	  					String sendMessage = HttpDownloadUtility.downloadFile(URL,"/home/student/Desktop"); 	  					
	 	  					out.writeUTF(sendMessage);
	 	  				}
	 	  			} catch(Exception e) {
	 	  				e.printStackTrace();
	 	  			}
	 	  		}
	 	  	}; 
	 	  	receive.start();
 	  	} catch(Exception e) {
 	  		e.printStackTrace();
 	  	}
 	}
 }
