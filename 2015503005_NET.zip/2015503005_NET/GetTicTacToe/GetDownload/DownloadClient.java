import java.net.*;
import java.io.*;
import java.util.*;

/*1. Write a server application which listens a given TCP port and 
it provides a simple http Service to pass back a requested file 
in the server's directory or subdirectory. 
The request from a browser should be in the form: 
"GET /path/filename.xyz". 
If no file name or only “ / ” in the request, the server passes the default index.html 
file from server’s directory. 
If requested file is not found, it passes “404 Object not found”. 
If requested file is found but it don’t have a permission to read, the servers passes “403 Forbidden”. 
If any other error is occurred, the server passes “400 Bad request”. 
The program argument is the port number. 
The default value of port number is 1234.*/

public class DownloadClient {
	public static void main(String[] args) throws Exception{
		Socket s = new Socket("localhost",1234);
 	  	DataInputStream in = new DataInputStream(s.getInputStream());
 	  	DataOutputStream out = new DataOutputStream(s.getOutputStream());
 	  	Scanner scan = new Scanner(System.in) ;
 	  	Thread send = new Thread() {
 	  		public void run() {
 	  			try {
 	  				String sendMessage = scan.nextLine();
 	  				while(sendMessage.substring(0,3).equals("GET")) {
 	  					System.out.println("SENDING " + sendMessage);
 	  					out.writeUTF(sendMessage);
 	  					sendMessage = scan.nextLine();
 	  				}
 	  			} catch(Exception e) {
 	  				e.printStackTrace();
 	  			}
 	  		}
 	  	}; 
		Thread receive = new Thread() {
	 	  	public void run() {
	 	  		try {
	 	  			while(true) {
	 	  				String receivedMessage = "";
	 	  				while(true) {
			 	  			receivedMessage = in.readUTF();
			 	  			System.out.println("SERVER SAYS :- " + receivedMessage);
		 	  			}
		 	  		}
	 	  		} catch(Exception e) {
	 	  			e.printStackTrace();
	 	  		}
	 	  	}
	 	}; 
 	  	send.start();
 	  	receive.start();
	}
}