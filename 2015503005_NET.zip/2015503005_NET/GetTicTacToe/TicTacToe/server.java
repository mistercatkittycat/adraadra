import java.net.*;
import java.io.*;

public class server
{
	public static void main(String args[]) throws Exception
	{
		ServerSocket ser=new ServerSocket(1234);

		while(true)
		{
			Socket player1=ser.accept();
			DataInputStream in1=new DataInputStream(player1.getInputStream());
			DataOutputStream out1=new DataOutputStream(player1.getOutputStream());
			out1.writeUTF("X");

			Socket player2=ser.accept();
			DataInputStream in2=new DataInputStream(player2.getInputStream());
			DataOutputStream out2=new DataOutputStream(player2.getOutputStream());
			out2.writeUTF("O");
			
			out1.writeUTF("connected");
			out2.writeUTF("connected");

			while(true)
			{
				out2.writeUTF(in1.readUTF());
				String s=in1.readUTF();
				if(s.equals("true"))
				{
					out2.writeUTF(s);
					break;
				}
				else
					out2.writeUTF(s);
				out1.writeUTF(in2.readUTF());
				s=in2.readUTF();
				if(s.equals("true"))
				{
					out1.writeUTF(s);
					break;
				}
				else
					out1.writeUTF(s);
			}
			player1.close();
			player2.close();
		}
	}
};