import java.net.*;
import java.io.*;
import java.util.*;

public class ClientDate  {
	public static void main(String[] args) throws Exception {
		Socket s = new Socket("localhost",13); 
		DataInputStream din = new DataInputStream(s.getInputStream());
		String date = din.readUTF();
		System.out.println(date);
		dout.close();
	}
}