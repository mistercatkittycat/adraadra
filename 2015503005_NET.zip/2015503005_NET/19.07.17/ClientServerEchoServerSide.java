import java.net.*;
import java.io.*;
import java.util.*;

/*Write a server application which listens on given TCP port. 
 reads string from client and sending back the same string to 
 client like standard echo service.
 The program argument is the port number. The default value of port number is 7.
 */

 public class ClientServerEchoServerSide {
 	  public static void main(String[] args) {
 	  	try {
	 	  	ServerSocket ss = new ServerSocket(7);
	 	  	Socket s = ss.accept();
	 	  	DataInputStream in = new DataInputStream(s.getInputStream());
	 	  	DataOutputStream out = new DataOutputStream(s.getOutputStream());
	 	  	Scanner scan = new Scanner(System.in) ;
	 	  	Thread receive = new Thread() {
	 	  		public void run() {
	 	  			try {
	 	  				while(true) {
	 	  					String receivedMessage = in.readUTF();
	 	  					String sendMessage = receivedMessage;
	 	  					out.writeUTF(sendMessage);
	 	  				}
	 	  			} catch(Exception e) {
	 	  				e.printStackTrace();
	 	  			}
	 	  		}
	 	  	}; 
	 	  	receive.start();
 	  	} catch(Exception e) {
 	  		e.printStackTrace();
 	  	}
 	}
 }