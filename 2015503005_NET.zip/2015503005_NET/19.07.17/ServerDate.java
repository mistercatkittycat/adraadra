import java.net.*;
import java.io.*;
import java.util.*;

public class ServerDate  {
	public static void main(String[] args) throws Exception {
		ServerSocket ss = new ServerSocket(13);
		System.out.println("PLEASE CONNECT CLIENT");
		Socket s = ss.accept();
		DataOutputStream dout = new DataOutputStream(s.getOutputStream());
		dout.writeUTF("Server Date = " +(new Date()).toString() );
		dout.close();
	}
}