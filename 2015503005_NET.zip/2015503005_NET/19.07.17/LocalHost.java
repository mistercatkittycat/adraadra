import java.net.*;

public class LocalHost {
	public static void main(String[] args) {
		try {
			InetAddress ip = InetAddress.getLocalHost();
			System.out.println("IP Address is "  + ip.getHostAddress() );
			System.out.println("Host Name is " + ip.getHostName() );
		} catch(UnknownHostException e) {
			e.printStackTrace();
		}
	}
}