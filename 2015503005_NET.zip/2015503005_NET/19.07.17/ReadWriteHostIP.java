import java.net.*;
import java.io.*;
import java.util.*;


/* Write a set of hostnames and IP addresses into a file 
 *	and read from them. 
 *	For each string, if its an IP address, find its hostname
 *	and if its a hostname, fidn its IP address...
 */

class WriteIntoFile {
	public static void write() {
		try {
			FileOutputStream out  = new FileOutputStream("fileofipandhostnames.txt");
			out.write(("192.168.117.154\n").getBytes());
			out.write(("frontend\n").getBytes());
			out.write(("216.58.196.100\n").getBytes());
			out.write(("www.google.com\n").getBytes());
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}

class ReadFromFile {
	public List<String> list = new ArrayList<String>(); 
	public void read() {
		try {
			BufferedReader buffer = new BufferedReader(new FileReader(new File("fileofipandhostnames.txt")));
			String str;
			while ((str = buffer.readLine()) != null){
				list.add(str);
			}
			buffer.close();		
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}

public class ReadWriteHostIP {
	public static void main(String[] args) {
		WriteIntoFile.write();
		ReadFromFile reader = new ReadFromFile();
		reader.read();
		for(String s : reader.list) {
			System.out.println();
			if(s.charAt(0)>='0' && s.charAt(0)<='9') {
				try {
					InetAddress host = InetAddress.getByName(s);
					System.out.println("String is an IP = " + s);
					System.out.println("Host Name is = " + host.getHostName());
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			else {
				try {
					InetAddress host = InetAddress.getByName(s);
					System.out.println("String is a hostname = " + s);
					System.out.println("IP Address is = " + host.getHostAddress());
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}