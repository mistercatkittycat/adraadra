import java.net.*;
import java.io.*;
import java.util.*;

/*Write a server application which listens on given TCP port. 
 reads string from client and sending back the same string to 
 client like standard echo service.
 The program argument is the port number. The default value of port number is 7.
 */

 public class ClientServerEchoClientSide {
 	  public static void main(String[] args) {
 	  	try {
 	  		Socket s = new Socket("localhost",7);
	 	  	DataInputStream in = new DataInputStream(s.getInputStream());
	 	  	DataOutputStream out = new DataOutputStream(s.getOutputStream());
	 	  	Scanner scan = new Scanner(System.in) ;
	 	  	Thread send = new Thread() {
	 	  		public void run() {
	 	  			try {
	 	  				String sendMessage = scan.nextLine();
	 	  				while(!sendMessage.equals("Terminate")) {
	 	  					out.writeUTF(sendMessage);
	 	  					sendMessage = scan.nextLine();
	 	  				}
	 	  				out.writeUTF(sendMessage);
	 	  			} catch(Exception e) {
	 	  				e.printStackTrace();
	 	  			}
	 	  		}
	 	  	}; 
 	  		Thread receive = new Thread() {
	 	  		public void run() {
	 	  			try {
	 	  				while(true) {
	 	  					String receivedMessage = "";
	 	  					while(!receivedMessage.equals("Terminate")) {
			 	  				receivedMessage = in.readUTF();
			 	  				System.out.println("SERVER:- " + receivedMessage);
		 	  				}
		 	  			}
	 	  			} catch(Exception e) {
	 	  				e.printStackTrace();
	 	  			}
	 	  		}
	 	  	}; 
	 	  	send.start();
	 	  	receive.start();
 	  	} catch(Exception e) {
 	  		e.printStackTrace();
 	  	}
 	}
 }