import java.net.*;
import java.io.*;

public class SnakeServer{
	public static void main(String [] args) throws Exception{
		ServerSocket ser=new ServerSocket(1234);
		Socket player1=ser.accept();
		Socket player2 = ser.accept();
		DataInputStream in1=new DataInputStream(player1.getInputStream());
		DataOutputStream out1=new DataOutputStream(player1.getOutputStream());
		DataInputStream in2 = new DataInputStream(player2.getInputStream());
		DataOutputStream out2 = new DataOutputStream(player2.getOutputStream());
		out1.writeUTF("connected");
		out2.writeUTF("connected");

		while(true){
			String s1 = in1.readUTF();
			out2.writeUTF(s1);
			String s2 = in2.readUTF();
			out1.writeUTF(s2);
			System.out.println(s1+" :: "+s2);
		}
	}
}